let data = JSON.parse(localStorage.getItem("michael2026")) || {
  xp: 0,
  level: 1,
  streak: 0,
  lastDate: "",
  completed: {},
  stats: {
    strength: 0,
    intelligence: 0,
    discipline: 0,
    knowledge: 0,
    health: 0
  }
};

const today = new Date().toDateString();

if (data.lastDate !== today) {
  if (data.lastDate !== "") data.streak++;
  data.completed = {};
  data.lastDate = today;
}

function complete(stat) {
  if (data.completed[stat]) return;

  data.completed[stat] = true;
  data.xp += 10;
  data.stats[stat]++;

  if (data.xp >= 50) {
    data.xp = 0;
    data.level++;
  }

  save();
  updateUI();
}

function save() {
  localStorage.setItem("michael2026", JSON.stringify(data));
}

function updateCharacter() {
  let char = document.getElementById("char");
  let title = document.getElementById("title");

  if (data.level < 5) {
    char.innerHTML = "🙂";
    title.innerText = "Beginner";
  } else if (data.level < 10) {
    char.innerHTML = "💪";
    title.innerText = "Rising";
  } else if (data.level < 20) {
    char.innerHTML = "🦾";
    title.innerText = "Disciplined";
  } else {
    char.innerHTML = "🔥";
    title.innerText = "Elite";
  }
}

function updateUI() {
  document.getElementById("xp").innerText = data.xp;
  document.getElementById("level").innerText = data.level;
  document.getElementById("streak").innerText = data.streak;

  document.getElementById("strength").innerText = data.stats.strength;
  document.getElementById("intelligence").innerText = data.stats.intelligence;
  document.getElementById("disciplineStat").innerText = data.stats.discipline;
  document.getElementById("knowledge").innerText = data.stats.knowledge;
  document.getElementById("healthStat").innerText = data.stats.health;

  ["strength","intelligence","discipline","knowledge","health"].forEach(stat => {
    let btn = document.getElementById(stat === "discipline" ? "discipline" : stat);
    if (data.completed[stat]) btn.disabled = true;
  });

  updateCharacter();
}

updateUI();